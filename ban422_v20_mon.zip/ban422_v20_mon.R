## ---- echo = TRUE--------------------------------------------------------------
str(Titanic)


## ---- echo = TRUE--------------------------------------------------------------
library(MASS)
data(deaths)
str(deaths)


## ---- echo = TRUE--------------------------------------------------------------
jacoby <- read.table("data/jacoby.txt")
summary(jacoby)


## ---- echo = TRUE--------------------------------------------------------------
plot(jacoby$x1)


## ---- echo = TRUE--------------------------------------------------------------
plot(jacoby$x1, jacoby$x2)


## ---- echo = TRUE--------------------------------------------------------------
plot(x2 ~ x1, data=jacoby)


## ---- echo = TRUE--------------------------------------------------------------
plot(x2 ~ x1, data=jacoby, xlab="First vector",
  ylab="Second vector", pch=16, col="#EB811B",
  cex=1.2)


## ---- echo = TRUE--------------------------------------------------------------
plot(x2 ~ x1, data=jacoby, xlab="First vector",
  ylab="Second vector", pch=16, col="#EB811B",
  cex=1.2)
abline(v=mean(jacoby$x1), h=mean(jacoby$x2),
  lty=2, lwd=2, col="#EB811B")


## ---- echo = TRUE--------------------------------------------------------------
library(lattice)
xyplot(x2 ~ x1, jacoby)


## ---- echo = TRUE--------------------------------------------------------------
xyplot(x2 ~ x1, jacoby, panel = function(x, y, ...) {
  panel.xyplot(x, y, ...)  
  panel.abline(h = mean(y), v=mean(x), lty = 2,
    lwd=2, col="#EB811B")  
})


## ---- echo = TRUE--------------------------------------------------------------
xyplot(x2 ~ x1, jacoby) +
  latticeExtra::layer(panel.abline(h=mean(y), v=mean(x),
  lty = 2, lwd=2, col="#EB811B"))


## ---- echo = TRUE--------------------------------------------------------------
library(ggplot2)
ggplot(jacoby) + geom_point(aes(x=x1, y="")) + xlab("")


## ---- echo = TRUE--------------------------------------------------------------
ggplot(jacoby) + geom_point(aes(x1, x2))


## ---- echo = TRUE--------------------------------------------------------------
p <- ggplot(jacoby) + geom_point(aes(x1, x2), 
  colour="#EB811B", size=2) + xlab("First vector") +
  ylab("Second vector") +
  theme(legend.position = "none")
p


## ---- echo = TRUE--------------------------------------------------------------
p + geom_hline(yintercept=mean(jacoby$x2), 
  colour="#EB811B", linetype=2) +
  geom_vline(xintercept=mean(jacoby$x1),
  colour="#EB811B", linetype=2)


## ---- echo = TRUE--------------------------------------------------------------
stripchart(jacoby, pch=1, xlab="Data Values",
  ylab="Variable", main="Scatterchart")


## ---- echo = TRUE--------------------------------------------------------------
stripchart(jacoby, method="jitter",
  jitter=0.05, pch=1,
  xlab="Data Values",
  ylab="Variable",
  main="Scatterchart with jittering")


## ---- echo = TRUE--------------------------------------------------------------
jacobyS <- stack(jacoby)
str(jacobyS, width=45, strict.width="cut")


## ---- echo = TRUE--------------------------------------------------------------
stripplot(ind ~ values, data=jacobyS, jitter.data=TRUE)


## ---- echo = TRUE--------------------------------------------------------------
#library(reshape2)
#jacobyS <- melt(jacoby)
p <- ggplot(jacobyS, aes(values, ind))
p + geom_point() + ylab("")


## ---- echo = TRUE--------------------------------------------------------------
set.seed(1)
p + geom_point() + ylab("") + 
  geom_jitter(position=position_jitter(0.1))


## ---- echo = TRUE--------------------------------------------------------------
boxplot(jacoby)


## ---- echo = TRUE--------------------------------------------------------------
bwplot(values ~ ind, data=jacobyS)


## ---- echo = TRUE--------------------------------------------------------------
p <- ggplot(jacobyS, aes(ind, values))
p + geom_boxplot() + xlab("")


## ---- echo = TRUE--------------------------------------------------------------
oldpar <- par(no.readonly=TRUE)
par(mfrow=c(2,2))
brks <- seq(15,55,by=5)
for (i in 1:4) {
 hist(jacoby[,i], breaks=brks, col="grey85",
 xlab=paste("x", i, ": seq(15, 55, by=5)", sep=""),
 freq=TRUE, main="")
}
par(oldpar)


## ------------------------------------------------------------------------------
oldpar <- par(no.readonly=TRUE)
par(mfrow=c(2,2))
for (i in 1:4) {
 hist(jacoby[,i], breaks=seq(17.5,52.5,by=5), col="grey85",
 xlab=paste("x", i, ": seq(17.5, 52.5, by=5)", sep=""), freq=TRUE, main="")
}
par(oldpar)


## ------------------------------------------------------------------------------
oldpar <- par(no.readonly=TRUE)
par(mfrow=c(2,2))
for (i in 1:4) {
 hist(jacoby[,i], breaks=seq(17.5,52.5,by=2.5), col="grey85",
 xlab=paste("x", i, ": seq(17.5, 52.5, by=2.5)", sep=""), freq=TRUE, main="")
}
par(oldpar)


## ---- echo = TRUE--------------------------------------------------------------
histogram(~ values | ind, data=jacobyS,
  breaks=seq(15,55,by=5), type="count",
  index.cond=list(c(3,4,1,2)))


## ---- echo = TRUE--------------------------------------------------------------
ggplot(jacobyS, aes(x=values)) + 
  geom_histogram(breaks=seq(15, 55, by=5)) + 
  facet_wrap(~ ind, ncol=2)


## ---- echo = TRUE--------------------------------------------------------------
oldpar <- par(no.readonly=TRUE)
par(mfrow=c(2,2))
for (i in 1:4) {
  plot(density(jacoby[,i], bw=1.5), main="",
    xlim=c(15,55), ylim=c(0, 0.15))
  rug(jacoby[,i], ticksize=0.07, lwd=2)
  title(main=paste("Smoothed histogram of x",
    i, sep=""))
}
par(oldpar)


## ---- echo = TRUE--------------------------------------------------------------
densityplot(~ values | ind, data=jacobyS, bw=1.5,
  index.cond=list(c(3,4,1,2)))


## ---- echo = TRUE--------------------------------------------------------------
ggplot(jacobyS, aes(x=values)) + 
  geom_density(bw=1.5) + geom_rug() +
  facet_wrap(~ ind, ncol=2) + 
  xlim(c(15, 55))


## ---- echo = TRUE--------------------------------------------------------------
oldpar <- par(no.readonly=TRUE)
par(mfrow=c(2,2))
for (i in 1:4) {
  plot(ecdf(jacoby[,i]), main="",
    xlim=c(15,55))
  title(main=paste("ECDF of x",
    i, sep=""))
}
par(oldpar)


## ---- echo = TRUE--------------------------------------------------------------
library(latticeExtra)
ecdfplot(~ values | ind, data=jacobyS,
  index.cond=list(c(3,4,1,2)))
detach(package:latticeExtra)


## ---- echo = TRUE--------------------------------------------------------------
ggplot(jacobyS, aes(x=values)) + 
  stat_ecdf() +
  facet_wrap(~ ind, ncol=2)


## ---- echo = TRUE--------------------------------------------------------------
oldpar <- par(no.readonly=TRUE)
par(mfrow=c(2,2))
x <- qunif(ppoints(100))
for (i in 1:4) {
  qqplot(x=x, y=jacoby[,i])
  title(main=paste("Uniform QQ of x",
    i, sep=""))
}
par(oldpar)


## ---- echo = TRUE--------------------------------------------------------------
oldpar <- par(no.readonly=TRUE)
par(mfrow=c(2,2))
for (i in 1:4) {
  qqnorm(y=jacoby[,i], xlab="", ylab="",
    ylim=c(15, 55), main="")
  title(main=paste("Normal QQ of x",
    i, sep=""))
}
par(oldpar)


## ---- echo = TRUE--------------------------------------------------------------
qqmath(~ values | ind, data=jacobyS,
  distribution=qunif,
  index.cond=list(c(3,4,1,2)))


## ---- echo = TRUE--------------------------------------------------------------
qqmath(~ values | ind, data=jacobyS,
  distribution=qnorm,
  index.cond=list(c(3,4,1,2)))


## ---- echo = TRUE--------------------------------------------------------------
ggplot(jacobyS, aes(sample=values)) + 
  stat_qq(distribution=qunif) +
  facet_wrap(~ ind, ncol=2)


## ---- echo = TRUE--------------------------------------------------------------
ggplot(jacobyS, aes(sample=values)) + 
  stat_qq(distribution=qnorm) +
  facet_wrap(~ ind, ncol=2)


## ---- echo = TRUE, eval=FALSE--------------------------------------------------
## library(foreign)
## QQQ <- read.spss("data/CY6_MS_CMB_STU_QQQ.sav", to.data.frame=TRUE)
## QQQ1 <- QQQ[,c(1,2,4,29,30,35,64,810:839,920)]
## QQQ1$math_mean <- apply(as.matrix(QQQ1[,8:17]), 1, mean)
## QQQ1$math_sd <- apply(as.matrix(QQQ1[,8:17]), 1, sd)
## QQQ1$read_mean <- apply(as.matrix(QQQ1[,18:27]), 1, mean)
## QQQ1$read_sd <- apply(as.matrix(QQQ1[,18:27]), 1, sd)
## QQQ1$sci_mean <- apply(as.matrix(QQQ1[,28:37]), 1, mean)
## QQQ1$sci_sd <- apply(as.matrix(QQQ1[,28:37]), 1, sd)
## QQQ <- read.spss("data/CY6_MS_CMB_STU_QQQ.sav", to.data.frame=TRUE, use.value.labels=FALSE)
## QQQ1$CNT_vl <- QQQ1$CNT
## QQQ1$CNT <- QQQ$CNT
## saveRDS(QQQ1, file="dicook/pisa_raw_subset.rds")


## ---- echo = TRUE, cache=TRUE--------------------------------------------------
QQQ1 <- readRDS("dicook/pisa_raw_subset.rds")
recodes <- c("'QES'='ESP'", "'QCH'='CHN'", "'QAR'='ARG'", "'TAP'='TWN'")
for (str in recodes) QQQ1$CNT <- car::recode(QQQ1$CNT, str)
QQQ2 <- droplevels(QQQ1[!(as.character(QQQ1$CNT) %in% c("QUC", "QUD", "QUE")),])
library(ISOcodes)
data("ISO_3166_1")
scores <- merge(QQQ2, ISO_3166_1[,c("Alpha_3", "Name")], by.x="CNT", by.y="Alpha_3", all.x=TRUE)
scores$Name[scores$CNT == "KSV"] <- "Kosovo"
saveRDS(scores, file="dicook/pisa_subset.rds")


## ---- echo = TRUE, cache=TRUE--------------------------------------------------
QQQ1 <- readRDS("dicook/pisa_raw_subset.rds")
recodes <- c("'QES'='ESP'", "'QCH'='CHN'", "'QAR'='ARG'", "'TAP'='TWN'")
CNT_count <- as.data.frame(table(QQQ1$CNT))
names(CNT_count) <- c("CNT", "n")
for(str in recodes) CNT_count$CNT <- car::recode(CNT_count$CNT, str)
CNT_count1 <- aggregate(CNT_count$n, list(CNT_count$CNT), sum)
CNT_count2 <- droplevels(CNT_count1[!(as.character(CNT_count1$Group.1) %in% c("QUC", "QUD", "QUE")),])
names(CNT_count2) <- c("CNT", "n")
library(ISOcodes)
data("ISO_3166_1")
countries <- merge(CNT_count2, ISO_3166_1, by.x="CNT", by.y="Alpha_3", all.x=TRUE)
countries$Name[countries$CNT == "KSV"] <- "Kosovo"
saveRDS(countries, file="dicook/countries.rds")


## ---- echo = TRUE, eval=TRUE, cache=TRUE---------------------------------------
QQQ1 <- readRDS("dicook/pisa_subset.rds")
countries <- readRDS("dicook/countries.rds")
a0 <- split(QQQ1, list(QQQ1$CNT, QQQ1$ST004D01T))


## ---- echo = TRUE, eval=TRUE---------------------------------------------------
math_mean <- sapply(a0, function(x) weighted.mean(x$math_mean, w=x$SENWT))
n2 <- length(math_mean)/2
country <- sapply(strsplit(names(math_mean), "\\."), "[", 1)[1:n2]
co <- match(country, countries$CNT)
nms <- countries$Name[co]
gender <- factor(sapply(strsplit(names(math_mean), "\\."), "[", 2))[1:n2]
o <- order(math_mean[1:n2])


## ---- echo = TRUE--------------------------------------------------------------
dotchart(math_mean[o], label=nms[o], cex=0.5, pt.cex=0.9, pch=3, xlim=c(325, 575))
points(math_mean[n2+o], 1:n2, cex=0.9, pch=4, col="brown1")
legend("bottomright", legend=levels(gender), col=c("black", "brown1"), pch=3:4, pt.cex=0.9, bty="n", cex=0.8)
title("PISA mean math PV means, age 15")


## ---- echo = TRUE, eval=TRUE---------------------------------------------------
library(matrixStats)
sqn <- sqrt(sapply(a0, function(x) sum(x$SENWT)))
math_se <- sapply(a0, function(x) weightedSd(x$math_mean, w=x$SENWT))/sqn


## ---- echo = TRUE--------------------------------------------------------------
dotchart(math_mean[o], label=nms[o], cex=0.5, pt.cex=0.9, pch=3, xlim=c(270, 650))
for (i in 1:n2) segments(x0=math_mean[o][i]-2*(math_se[o][i]), y0=i, x1=math_mean[o][i]+2*(math_se[o][i]), lwd=2)
points(math_mean[n2+o], (1:n2)-0.25, cex=0.9, pch=4, col="brown1")
for (i in 1:n2) segments(x0=math_mean[n2+o][i]-2*(math_se[n2+o][i]), y0=i-0.25, x1=math_mean[n2+o][i]+2*(math_se[n2+o][i]), lwd=2, col="brown1")
legend("bottomright", legend=levels(gender), col=c("black", "brown1"), pch=3:4, pt.cex=0.9, bty="n", cex=0.8)
title("PISA math PV means, age 15, +/- 2se")


## ---- echo = TRUE, eval=TRUE---------------------------------------------------
read_mean <- sapply(a0, function(x) weighted.mean(x$read_mean, w=x$SENWT))
ro <- order(read_mean[1:n2])


## ---- echo = TRUE, eval=TRUE---------------------------------------------------
sci_mean <- sapply(a0, function(x) weighted.mean(x$sci_mean, w=x$SENWT))
so <- order(sci_mean[1:n2])


## ------------------------------------------------------------------------------
dotchart(read_mean[ro], label=nms[ro], cex=0.5, pt.cex=0.9, pch=3, xlim=c(325, 575))
points(read_mean[n2+ro], 1:n2, cex=0.9, pch=4, col="brown1")
legend("bottomright", legend=levels(gender), col=c("black", "brown1"), pch=3:4, pt.cex=0.9, bty="n", cex=0.8)
title("PISA mean reading PV means, age 15")


## ------------------------------------------------------------------------------
dotchart(sci_mean[so], label=nms[so], cex=0.5, pt.cex=0.9, pch=3, xlim=c(325, 575))
points(sci_mean[n2+so], 1:n2, cex=0.9, pch=4, col="brown1")
legend("bottomright", legend=levels(gender), col=c("black", "brown1"), pch=3:4, pt.cex=0.9, bty="n", cex=0.8)
title("PISA mean science PV means, age 15")


## ---- echo = TRUE, eval=TRUE---------------------------------------------------
math_gap <- math_mean[1:n2] - math_mean[n2+(1:n2)]
read_gap <- read_mean[1:n2] - read_mean[n2+(1:n2)]
sci_gap <- sci_mean[1:n2] - sci_mean[n2+(1:n2)]
gaps <- data.frame(math_gap, read_gap, sci_gap, iso_a3=country,
  iso_a2=countries$Alpha_2[co])


## ---- echo = TRUE, eval=TRUE---------------------------------------------------
library(rnaturalearth)
library(rnaturalearthdata)
data(countries50)
library(sf)
countries50 <- st_as_sf(countries50)


## ---- echo = TRUE--------------------------------------------------------------
world_gaps <- merge(countries50, gaps, by="iso_a2", all.x=TRUE)
library(tmap)
tm_shape(world_gaps) + tm_fill("math_gap", palette="div", n=7, style="jenks", midpoint=0)
#ttm()
#last_map()


## ---- echo = TRUE--------------------------------------------------------------
library(RColorBrewer)
opar <- par(cex=0.7)
display.brewer.all()
par(opar)


## ------------------------------------------------------------------------------
suppressPackageStartupMessages(library(viridis))
library(colorspace)
library(ggplot2)
#devtools::install_github("wilkelab/cowplot")
#install.packages("colorspace", repos = "http://R-Forge.R-project.org")
#devtools::install_github("clauswilke/colorblindr")
library(colorblindr)
n_col <- 10
swatchplot(
"terrain.colors"=rev(terrain.colors(n_col)),
"heat"=rev(heat.colors(n_col)), 
"ggplot default"=rev(scales::seq_gradient_pal(low = "#132B43", high = "#56B1F7", space = "Lab")(seq(0, 1, length=n_col))), 
"brewer blues"=scales::gradient_n_pal(scales::brewer_pal(type="seq")(9))(seq(0, 1, length=n_col)), 
"brewer yellow-green-blue"=scales::gradient_n_pal(scales::brewer_pal(type="seq", palette = "YlGnBu")(9))(seq(0, 1, length=n_col)), 
"viridis"=rev(viridis(n_col)), 
"magma"=rev(magma(n_col))
)


## ------------------------------------------------------------------------------
suppressPackageStartupMessages(library(cartography))
display.carto.all(n = 10)


## ------------------------------------------------------------------------------
n_col <- 8
swatchplot(
  "Okabe Ito"=palette_OkabeIto,
  "ColorBrewer accent"=brewer.pal(n_col, "Accent"),
  "ColorBrewer Pastel2"=brewer.pal(n_col, "Pastel2"),
  "Qualitative HCL"=qualitative_hcl(n_col)
)


## ------------------------------------------------------------------------------
n_col <- 10
swatchplot(
"terrain.colors"=rev(terrain.colors(n_col)),
"terrain HCL"=rev(terrain_hcl(n_col)),
"heat"=rev(heat.colors(n_col)), 
"heat HCL"=rev(heat_hcl(n_col)),
"rainbow"=rainbow(n_col),
"rainbow HCL"=rainbow_hcl(n_col)
)


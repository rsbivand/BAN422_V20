## ---- echo = TRUE, eval=TRUE---------------------------------------------------
QQQ1 <- readRDS("../mon/dicook/pisa_subset.rds")
countries <- readRDS("../mon/dicook/countries.rds")
countries$Alpha_2[countries$Name == "Kosovo"] <- "XK"
a0 <- split(QQQ1, list(QQQ1$CNT, QQQ1$ST004D01T))


## ---- echo = TRUE, eval=TRUE---------------------------------------------------
math_mean <- sapply(a0, function(x) weighted.mean(x$math_mean, w=x$SENWT))
n2 <- length(math_mean)/2
country <- sapply(strsplit(names(math_mean), "\\."), "[", 1)[1:n2]
co <- match(country, countries$CNT)
gender <- factor(sapply(strsplit(names(math_mean), "\\."), "[", 2))


## ---- echo = TRUE, eval=TRUE---------------------------------------------------
library(matrixStats)
sqn <- sqrt(sapply(a0, function(x) sum(x$SENWT)))
math_se <- sapply(a0, function(x) weightedSd(x$math_mean, w=x$SENWT))/sqn


## ---- echo = TRUE, eval=TRUE---------------------------------------------------
read_mean <- sapply(a0, function(x) weighted.mean(x$read_mean, w=x$SENWT))


## ---- echo = TRUE, eval=TRUE---------------------------------------------------
sci_mean <- sapply(a0, function(x) weighted.mean(x$sci_mean, w=x$SENWT))


## ---- echo = TRUE, eval=TRUE---------------------------------------------------
math_mean_female <- math_mean[gender == "Female"]
math_mean_male <- math_mean[gender == "Male"]
math_se_female <- math_se[gender == "Female"]
math_se_male <- math_se[gender == "Male"]
math_gap <- math_mean_female - math_mean_male
read_mean_female <- read_mean[gender == "Female"]
read_mean_male <- read_mean[gender == "Male"]
read_gap <- read_mean_female - read_mean_male
sci_mean_female <- sci_mean[gender == "Female"]
sci_mean_male <- sci_mean[gender == "Male"]
sci_gap <- sci_mean_female - sci_mean_male
df <- data.frame(math_mean_female, math_mean_male, math_se_female, math_se_male,
  read_mean_female, read_mean_male, sci_mean_female, sci_mean_male,
  math_gap, read_gap, sci_gap, iso_a3=country, iso_a2=countries$Alpha_2[co])


## ---- echo = TRUE, eval=TRUE---------------------------------------------------
library(rnaturalearth)
library(rnaturalearthdata)
data(countries50)
library(sf)
countries50 <- st_as_sf(countries50)
countries50$iso_a2[countries50$name == "Kosovo"] <- "XK"


## ---- echo = TRUE--------------------------------------------------------------
world_gaps <- merge(countries50[!is.na(countries50$iso_a2),], df, by="iso_a2", all.x=TRUE)
library(tmap)
tm_shape(world_gaps) + tm_fill("math_gap", palette="RdYlGn", n=7, style="jenks", midpoint=0)


## ---- echo = TRUE--------------------------------------------------------------
x <- na.exclude(world_gaps$math_gap)
nclass.Sturges(x)
nclass.scott(x)
(n <- nclass.FD(x))
nclass.Sturges(x[sign(x) == 1L])
nclass.Sturges(x[sign(x) == -1L])


## ---- echo = TRUE--------------------------------------------------------------
n
range(x)
(p <-pretty(x, n=n))
length(p)
(p <-pretty(x, n=n, high.u.bias=3))
length(p)


## ---- echo = TRUE--------------------------------------------------------------
suppressPackageStartupMessages(library(classInt))
(ppd <- classIntervals(x, n=n, style="pretty",
  cutlabels=TRUE))
(pp3 <- classIntervals(x, n=n, style="pretty",
  high.u.bias=3, cutlabels=TRUE))


## ------------------------------------------------------------------------------
library(RColorBrewer)
pal <- brewer.pal(7, "RdYlGn")
oopar <- par(mfrow=c(1, 2))
plot(ppd, pal=pal, main="Pretty (default)", xlab="", ylab="")
plot(pp3, pal=pal, main="Pretty (compressed)", xlab="", ylab="")
par(oopar)


## ---- echo = TRUE--------------------------------------------------------------
(pq7 <- classIntervals(x, n=n, style="quantile",
  type=7L, dataPrecision=2))
(pq3 <- classIntervals(x, n=n, style="quantile",
  type=3L, dataPrecision=2))


## ------------------------------------------------------------------------------
oopar <- par(mfrow=c(1, 2))
plot(pq7, pal=pal, main="Quantile type=7", xlab="", ylab="")
plot(pq3, pal=pal, main="Quantile type=3", xlab="", ylab="")
par(oopar)


## ---- echo = TRUE--------------------------------------------------------------
(peq <- classIntervals(x, n=n, style="equal",
  dataPrecision=2))
diff(peq$brks)
(psd <- classIntervals(x, n=n, style="sd", 
  high.u.bias=3, dataPrecision=2))
(psd$brks-attr(psd, "parameters")["center"]) /
  attr(psd, "parameters")["scale"]


## ------------------------------------------------------------------------------
oopar <- par(mfrow=c(1, 2))
plot(peq, pal=pal, main="Equal intervals", xlab="", ylab="")
plot(psd, pal=pal, main="Standard deviations", xlab="", ylab="")
par(oopar)


## ---- echo = TRUE--------------------------------------------------------------
(phc7 <- classIntervals(x, n=n, style="hclust", 
  method="complete", dataPrecision=2))
(phc5 <- getHclustClassIntervals(phc7, 5))


## ------------------------------------------------------------------------------
oopar <- par(mfrow=c(1, 2))
plot(phc7, pal=pal, main="Hierarchical clusters (7)", xlab="", ylab="")
plot(phc5, pal=pal, main="Hierarchical clusters (5)", xlab="", ylab="")
par(oopar)


## ------------------------------------------------------------------------------
set.seed(1)
(pk7 <- classIntervals(x, n=n, style="kmeans",
  dataPrecision=2))
set.seed(1)
(pbc7 <- classIntervals(x, n=n, style="bclust", 
  verbose=FALSE, dataPrecision=2))


## ------------------------------------------------------------------------------
oopar <- par(mfrow=c(1, 2))
plot(pk7, pal=pal, main="K-means clusters", xlab="", ylab="")
plot(pbc7, pal=pal, main="Bagged clusters", xlab="", ylab="")
par(oopar)


## ---- echo = TRUE--------------------------------------------------------------
(pj7 <- classIntervals(x, n=n, style="jenks",
  dataPrecision=2))
(pf7 <- classIntervals(x, n=n, style="fisher",
  dataPrecision=2))


## ------------------------------------------------------------------------------
oopar <- par(mfrow=c(1, 2))
plot(pj7, pal=pal, main="Jenks natural breaks", xlab="", ylab="")
plot(pf7, pal=pal, main="Fisher natural breaks", xlab="", ylab="")
par(oopar)


## ---- echo = TRUE--------------------------------------------------------------
str(findCols(pj7))
str(findInterval(x, pj7$brks, all.inside=TRUE,
  left.open=TRUE))
str(as.integer(cut(x, breaks=pj7$brks,
  include.lowest=TRUE)))


## ---- echo = TRUE--------------------------------------------------------------
suppressPackageStartupMessages(library(ggplot2))
stat_bin


## ---- echo = TRUE--------------------------------------------------------------
StatBin


## ---- echo = TRUE--------------------------------------------------------------
cat(capture.output(print(StatBin$compute_group))[-(1:5)], sep="\n")


## ---- echo = TRUE--------------------------------------------------------------
ggplot2:::bin_breaks_bins


## ---- echo = TRUE--------------------------------------------------------------
cat(capture.output(print(ggplot2:::bin_breaks_width))[-(4:8)], sep="\n")


## ---- echo = TRUE--------------------------------------------------------------
ggplot2:::bin_breaks


## ---- echo = TRUE--------------------------------------------------------------
ggplot2:::bins


## ---- echo = TRUE--------------------------------------------------------------
library(mapview)
mapview(world_gaps, zcol="math_gap",
  col.regions=pal, at=pj7$brks)


## ---- echo = TRUE--------------------------------------------------------------
library(tmap)
tm_shape(world_gaps) + tm_fill("math_gap",
  n=n, style="jenks", palette=pal, midpoint=0) +
  tm_borders(lwd=0.5, alpha=0.4)


## ---- echo = TRUE--------------------------------------------------------------
tm_shape(world_gaps) + tm_fill(c("math_mean_female", "math_mean_male"), n=7, style="jenks", palette=pal) +
  tm_facets(free.scales=FALSE) + tm_borders(lwd=0.5, alpha=0.4) + tm_layout(panel.labels=c("Female", "Male"))


## ---- echo = TRUE--------------------------------------------------------------
nordics <- c("DNK", "FIN", "ISL", "NOR", "SWE")
a1 <- a0[which(sapply(strsplit(names(a0), "\\."),
  "[", 1) %in% nordics)]
a11 <- do.call("rbind", a1)
a11$CNT <- droplevels(a11$CNT)
levels(a11$ST013Q01TA) <- sub("More than",
  ">", sub(" books", "", levels(a11$ST013Q01TA)))
saveRDS(a11, "../mon/dicook/a11.rds")
library(lattice)
library(ggplot2)


## ---- echo = TRUE--------------------------------------------------------------
histogram(~ sci_mean | CNT*ST004D01T, data=a11, main="Science mean PVs", xlab="")


## ---- echo = TRUE--------------------------------------------------------------
ggplot(a11, aes(x=sci_mean)) + geom_histogram() + facet_wrap(~ ST004D01T + CNT, nrow=2) +
  ggtitle("Science mean PVs") + xlab("")


## ---- echo = TRUE--------------------------------------------------------------
histogram(~ sci_mean | CNT*ST004D01T, data=a11, main="Science mean PVs", xlab="", type="count")


## ---- echo = TRUE--------------------------------------------------------------
densityplot(~ sci_mean | ST004D01T, groups=CNT, data=a11, auto.key=list(space="right"),
  plot.points=FALSE, main="Science mean PVs", xlab="")


## ---- echo = TRUE--------------------------------------------------------------
ggplot(a11, aes(x=sci_mean)) + geom_density(aes(colour=CNT)) + facet_wrap(~ ST004D01T, ncol=2) + 
  ggtitle("Science mean PVs") + xlab("")


## ---- echo = TRUE--------------------------------------------------------------
densityplot(~ sci_mean | ST004D01T, groups=CNT, data=a11, auto.key=list(space="right"),
  plot.points=FALSE, main="Science mean PVs", xlab="", type=c("l", "g"))


## ---- echo = TRUE--------------------------------------------------------------
densityplot(~ sci_mean | CNT, groups=ST004D01T, a11, auto.key=list(space="right"),
  plot.points=FALSE, main="Science mean PVs", xlab="")


## ---- echo = TRUE--------------------------------------------------------------
ggplot(a11, aes(x=sci_mean)) + geom_density(aes(colour=ST004D01T)) + facet_wrap(~ CNT, ncol=3) + 
  ggtitle("Science mean PVs") + xlab("")


## ---- echo = TRUE--------------------------------------------------------------
bwplot(sci_mean ~ ST013Q01TA | ST004D01T, a11, main="Science mean PVs", xlab="books", ylab="")


## ---- echo = TRUE--------------------------------------------------------------
ggplot(na.omit(a11), aes(ST013Q01TA, sci_mean)) + geom_boxplot(aes(group=ST013Q01TA)) +
  facet_wrap(~ ST004D01T) + ggtitle("Science mean PVs") + xlab("books") + ylab("")


## ---- echo = TRUE--------------------------------------------------------------
bwplot(sci_mean ~ ST013Q01TA | ST004D01T, a11, main="Science mean PVs", xlab="books", ylab="", varwidth=TRUE)


## ---- echo = TRUE--------------------------------------------------------------
ggplot(na.omit(a11), aes(ST013Q01TA, sci_mean)) + geom_boxplot(aes(group=ST013Q01TA), varwidth=TRUE) +
  facet_wrap(~ ST004D01T) + ggtitle("Science mean PVs") + xlab("books") + ylab("")


## ---- echo = TRUE--------------------------------------------------------------
cat(system('echo "search()" | R --no-save --vanilla', intern=TRUE)[20:23], sep="\n")


## ---- echo = TRUE--------------------------------------------------------------
capabilities()
grSoftVersion()


## ---- echo = TRUE--------------------------------------------------------------
a11 <- readRDS("../mon/dicook/a11.rds")
png("plot.png")
dev.cur()
boxplot(sci_mean ~ ST004D01T, a11)
dev.off()


## ---- echo = TRUE--------------------------------------------------------------
png(tempfile())
unlist(dev.capabilities())
dev.size("in")
dev.interactive()
dev.off()


## ---- echo = TRUE--------------------------------------------------------------
opar <- par(mfrow=c(2,2))
boxplot(sci_mean ~ ST004D01T, a11, las=0)
boxplot(sci_mean ~ ST004D01T, a11, las=1)
boxplot(sci_mean ~ ST004D01T, a11, lwd=2)
boxplot(sci_mean ~ ST004D01T, a11, pch=4)
par(opar)


## ---- echo = TRUE--------------------------------------------------------------
opar <- par(mfrow=c(2,2))
boxplot(sci_mean ~ ST004D01T, a11, axes=FALSE)
boxplot(sci_mean ~ ST004D01T, a11, axes=FALSE)
axis(2, las=1)
boxplot(sci_mean ~ ST004D01T, a11, axes=FALSE)
axis(2, las=1)
axis(1, at=1:2, labels=levels(a11$ST004D01T))
boxplot(sci_mean ~ ST004D01T, a11, axes=FALSE)
axis(2, las=1)
axis(1, at=1:2, labels=levels(a11$ST004D01T))
box()
par(opar)


## ---- echo = TRUE--------------------------------------------------------------
layout(cbind(c(1, 1), c(2,2)))
opar <- par(mar=c(3, 3, 0, 0)+0.1)
boxplot(sci_mean ~ ST004D01T, a11)
par(mar=c(10, 3, 4, 0)+0.1)
boxplot(sci_mean ~ ST004D01T, a11)
layout(1)


## ---- echo = TRUE--------------------------------------------------------------
library("jpeg")
im <- as.raster(readJPEG("image001.jpg"))
prop <- dim(im)[2]/dim(im)[1]
png("plot1.png")
par("din")
plot(1, type="n", axes=FALSE, xlim=c(1, 10),
  ylim=c(1, 10), asp=1, ann=FALSE)
rasterImage(im, 1:9, 1:9, (1:9) + prop, 2:10)
dev.off()


## ---- echo = TRUE--------------------------------------------------------------
opar <- par(oma=rep(3, 4), bg="gray80")
plot(c(0, 1), c(0, 1), type="n", ann=FALSE,
  axes=FALSE); box("outer", col="gray")
par(xpd=TRUE)
rect(-1, -1, 2, 2, col="gray90")
box("figure"); par(xpd=FALSE)
rect(-1, -1, 2, 2, col="gray80")
box("plot", lty="dashed")
text(.5, .5, "Plot Region")
mtext("Figure Region", side=3, line=2)
for (i in 1:4) mtext(paste("Outer margin", i),
  side=i, line=1, outer=TRUE)
par(opar)

## ---- echo = TRUE--------------------------------------------------------------
opar <- par(mfrow=c(2,2), bg="transparent")
plot(lm(math_mean ~ read_mean, data=a11), pch=".")
par(opar)


library(shiny)

# Define UI for application 
shinyUI(fluidPage(

  # Application title
  titlePanel("Population projections for Norway"),

  # Sidebar with a slider input 
  sidebarLayout(
    sidebarPanel(
      selectInput("start",
                  label="Choose start year:",
                  choices=list("1960"=6, "1996"=7, "2006"=8, "2011"=9), selected=1),
      selectInput("death_rates",
                  label="Choose death rates:",
                  choices=list("1961-65"=1, "1991-95"=2, "1996-2000"=3, "2001-05"=4, "2006-10"=5), selected=1),
      selectInput("birth_rates",
                  label="Choose birth rates:",
                  choices=list("1961-65"=6, "1991-95"=7, "1996-2000"=8, "2001-05"=9, "2006-10"=10), selected=1),
      selectInput("sex_ratio",
                  label="Choose sex ratio:",
                  choices=list("105/200"=1, "120/200"=2), selected=1),
      sliderInput("animation", "Run projection", 1, 10, 1, step=1,
                  animate=animationOptions(interval=1000, loop=FALSE))
    ),

    # Show a plot 
    mainPanel(
      plotOutput("distPlot")
    )
  )
))


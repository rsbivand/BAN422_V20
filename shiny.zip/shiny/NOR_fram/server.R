pyramid3 <- function(kpop0, mpop0, kpop1, mpop1, maxpop, title="", rns)
{
        w <- 2.2 * maxpop
        m <- w / 2
        h <- w
        slice <- h / length(kpop0)
        op <- par(xaxt="n", yaxt="n", pty="s")
        plot(c(0,w), c(0,h), type="n", main=paste0(title, " (",
          round(sum(c(kpop1, mpop1))), ")", sep=""), xlab="", ylab="")
        segments(0,0,w,0)
        segments(m,0,m,h)
        for (i in 1:length(kpop0)) {
                rect(m-mpop1[i], slice*(i-1), m, slice*i, lty=1, col="lightblue")
                rect(m, slice*(i-1), m+kpop1[i], slice*i, lty=1, col="lightyellow")
                rect(m-mpop0[i], slice*(i-1), m, slice*i, lty=1, lwd=2, border="darkblue")
                rect(m, slice*(i-1), m+kpop0[i], slice*i, lty=1, lwd=2, border="orange")
                text(x=m, y=slice*(i-0.5), labels=rns[i], cex=0.8)
        }
	abline(h=c(4,13)*slice, lwd=3, col="red")
	par(op)
	par(yaxt="s")
}

framskriv <- function(perioder, frukt, kdoed, mdoed, kpop0, mpop0, gprop, step=5, start)
{
	kp <- kpop0
	mp <- mpop0
	n <- length(kp)
	ksur <- matrix(0, n, n)
	ksur[1,] <- step*frukt/1000
	for (i in 1:(n-1)) ksur[(i+1), i] <- 1-(step*kdoed[i]/100000)
	msur <- matrix(0, n, n)
	for (i in 1:(n-1)) msur[(i+1), i] <- 1-(step*mdoed[i]/100000)

	res <- matrix(nrow=perioder+1,ncol=2)
	res[1,1] <- 0
	res[1,2] <- sum(kp) + sum(mp)
	kres <- matrix(0, n, perioder+1)
	kres[,1] <- kp
	mres <- matrix(0, n, perioder+1)
	mres[,1] <- mp
        titles <- character(perioder)
	for (p in 1:perioder) {
		kt <- ksur %*% kp
		kt[n] <- kt[n] + kp[n]*(1-(step*kdoed[n]/100000))
		mt <- msur %*% mp
		mt[n] <- mt[n] + mp[n]*(1-(step*mdoed[n]/100000))
		kp <- kt
		kp[1] <- (1-gprop)*kt[1]
		mp <- mt
		mp[1] <- gprop*kt[1]
		res[p+1,1] <- p
		res[p+1,2] <- sum(kp) + sum(mp)
		kres[,(p+1)] <- kp
		mres[,(p+1)] <- mp
                titles[p] <- paste("now:", (start+(step*p)))
	}
	list(kres, mres, titles)
}


kp <- read.table("data/kpop", header=TRUE, row.names=1)
mp <- read.table("data/mpop", header=TRUE, row.names=1)

shinyServer(function(input, output) {

  step <- 5L
  rns <- row.names(kp)
  starts <- c(1960, 1996, 2006, 2010)

  output$distPlot <- renderPlot({
    gprop <- ifelse(as.integer(input$sex_ratio) == 2, 120/200, 105/200)
    res <- framskriv(10, kp[, as.integer(input$birth_rates)], 
      kp[, as.integer(input$death_rates)],
      mp[, as.integer(input$death_rates)],  
      kp[, as.integer(input$start)+5], mp[, as.integer(input$start)], 
      gprop, step=step, starts[as.integer(input$start)-5])
    maxpop <- max(c(res[[1]], res[[2]]))
    p <- as.integer(input$animation)
    pyramid3(res[[1]][,1], res[[2]][,1], res[[1]][,(p+1)], res[[2]][,(p+1)], 
	maxpop, res[[3]][p], rns)
    
  })
})

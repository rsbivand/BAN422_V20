#source("pop.R")
pyramid2 <- function(kpop0, mpop0, kpop1, mpop1, title="", rns)
{
        mk0 <- max(kpop0)
        mm0 <- max(mpop0)
        mk1 <- max(kpop1)
        mm1 <- max(mpop1)
        w <- 2.2 * max(c(mk0, mm0, mk1, mm1))
        m <- w / 2
        h <- w
        slice <- h / length(kpop0)
        op <- par(xaxt="n", yaxt="n", pty="s")
        plot(c(0,w), c(0,h), type="n", main=paste0(title, " (",
          sum(c(kpop1, mpop1)), ")", sep=""), xlab="", ylab="")
        segments(0,0,w,0)
        segments(m,0,m,h)
        for (i in 1:length(kpop0)) {
                rect(m-mpop1[i], slice*(i-1), m, slice*i, lty=1, col="lightblue")
                rect(m, slice*(i-1), m+kpop1[i], slice*i, lty=1, col="lightyellow")
                rect(m-mpop0[i], slice*(i-1), m, slice*i, lty=1, lwd=2, border="darkblue")
                rect(m, slice*(i-1), m+kpop0[i], slice*i, lty=1, lwd=2, border="orange")
                text(x=m, y=slice*(i-0.5), labels=rns[i], cex=0.8)
        }
	par(op)
	par(yaxt="s")
}

kp <- read.table("data/kpop", header=TRUE, row.names=1)
mp <- read.table("data/mpop", header=TRUE, row.names=1)


shinyServer(function(input, output) {

  output$distPlot <- renderPlot({

    pyramid2(kp[, 11], mp[, 6], kp[, (10+as.integer(input$select))],
        mp[, (5+as.integer(input$select))],
        paste("Norge", substr(names(mp)[5+as.integer(input$select)], 4, 7)),
        rns=row.names(kp))
  })
})

library(shiny)

# Define UI for application 
shinyUI(fluidPage(

  # Application title
  titlePanel("Population pyramids for Norway: comparing with 1960"),

  # Sidebar 
  sidebarLayout(
    sidebarPanel(
      selectInput("select",
                  label=h3("Choose year:"),
                  choices=list("1960"=1, "1996"=2, "2006"=3, "2011"=4),
                  selected=1)
    ),

    # Show a plot 
    mainPanel(
      plotOutput("distPlot")
    )
  )
))

